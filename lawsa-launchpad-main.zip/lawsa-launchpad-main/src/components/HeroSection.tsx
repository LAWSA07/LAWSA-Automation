import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Zap, GitBranch, Bot } from "lucide-react";
import heroImage from "@/assets/hero-automation.jpg";

const HeroSection = () => {
  return (
    <section className="relative py-20 md:py-28 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-subtle"></div>
      
      <div className="container relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col justify-center space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center rounded-full border px-3 py-1 text-sm bg-primary/10 border-primary/20 text-primary">
                <Zap className="mr-2 h-4 w-4" />
                Automate everything, effortlessly
              </div>
              
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
                Build powerful{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  workflows
                </span>{" "}
                without code
              </h1>
              
              <p className="max-w-[600px] text-xl text-muted-foreground md:text-2xl">
                Connect your tools, automate your processes, and scale your business with lawsa's 
                intuitive visual workflow builder.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-primary text-lg px-8">
                Start building for free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button size="lg" variant="outline" className="text-lg px-8">
                <Play className="mr-2 h-5 w-5" />
                Watch demo
              </Button>
            </div>
            
            <div className="flex items-center space-x-8 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <div className="h-2 w-2 bg-primary rounded-full"></div>
                <span>Free forever plan</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="h-2 w-2 bg-primary rounded-full"></div>
                <span>No credit card required</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 to-primary-glow/20 p-8 shadow-glow">
              <img
                src={heroImage}
                alt="Workflow automation interface"
                className="w-full h-auto rounded-lg shadow-lg animate-float"
              />
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-primary text-primary-foreground p-3 rounded-full shadow-primary animate-float" style={{ animationDelay: '1s' }}>
                <GitBranch className="h-6 w-6" />
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-primary-glow text-primary-foreground p-3 rounded-full shadow-primary animate-float" style={{ animationDelay: '2s' }}>
                <Bot className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;