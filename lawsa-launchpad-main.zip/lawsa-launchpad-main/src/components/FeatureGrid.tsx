import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Workflow, 
  Zap, 
  Shield, 
  Code, 
  Globe, 
  BarChart3,
  Clock,
  Users,
  Database
} from "lucide-react";

const features = [
  {
    icon: Workflow,
    title: "Visual Workflow Builder",
    description: "Drag and drop to create complex automations without writing a single line of code."
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Execute thousands of workflows per minute with our optimized automation engine."
  },
  {
    icon: Globe,
    title: "500+ Integrations",
    description: "Connect with all your favorite tools and services through our extensive integration library."
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Bank-grade security with SOC 2 compliance, encryption, and advanced access controls."
  },
  {
    icon: Code,
    title: "Custom Code Support",
    description: "Extend your workflows with custom JavaScript functions and external APIs."
  },
  {
    icon: BarChart3,
    title: "Real-time Analytics",
    description: "Monitor performance, track executions, and optimize your workflows with detailed insights."
  },
  {
    icon: Clock,
    title: "Smart Scheduling",
    description: "Set up time-based triggers, recurring tasks, and intelligent retry mechanisms."
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description: "Share workflows, manage permissions, and collaborate seamlessly across your organization."
  },
  {
    icon: Database,
    title: "Data Transformation",
    description: "Transform, filter, and manipulate data as it flows through your automation pipelines."
  }
];

const FeatureGrid = () => {
  return (
    <section id="features" className="py-20 md:py-28">
      <div className="container">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Everything you need to{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              automate
            </span>
          </h2>
          <p className="max-w-[800px] text-lg text-muted-foreground md:text-xl mx-auto">
            Powerful features that make workflow automation accessible to everyone, from solo entrepreneurs to enterprise teams.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-border/50 hover:border-primary/20 transition-colors hover:shadow-glow/20">
              <CardHeader>
                <div className="h-12 w-12 bg-gradient-primary rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureGrid;